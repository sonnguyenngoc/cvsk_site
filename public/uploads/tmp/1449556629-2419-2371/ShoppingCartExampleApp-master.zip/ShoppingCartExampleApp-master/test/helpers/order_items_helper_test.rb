require 'test_helper'

class OrderItemsHelperTest < ActionView::TestCase
end
